<h1>Hi, {{ $name }}</h1>
l<p>Sending Mail from Laravel.</p>